

Serv_Set_1, Serv_Set_2, Serv_Set_3,...,Serv_Set_100 correspond to the node named 1,2,3,...,100 respectively. Each file is a candiate services and contains 10000 services.

Each service concludes five QoS indicator, namely response time, price, availability, reputation and throughput, and the value ranges of the five indicators are [1,10], [20,100], [0.6,0.999], [0.8,0.999], [1,20] respectively.

Each file has 10000 services.